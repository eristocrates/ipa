/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.jena.shacl.sys;

import org.apache.jena.graph.Graph;
import org.apache.jena.graph.Node;
import org.apache.jena.shacl.Shapes;
import org.apache.jena.sparql.core.DatasetGraph;
import org.apache.jena.sparql.core.DatasetGraphWrapper;

/** A dataset that adds a validation wrapper to every graph obtained via
 * "getDefaultGraph", "getGrapH" io "getUnionGraph".
 *
 *  <em>Experimental</em>
 *
 * @see ValidationGraph
 */
public class DatasetGraphValidate extends DatasetGraphWrapper {

    private Shapes shapes;

    public DatasetGraphValidate(DatasetGraph dsg, Shapes shapes) {
        super(dsg);
        this.shapes = shapes;
    }

    @Override
    public ValidationGraph getDefaultGraph()
    { return wrap(super.getDefaultGraph()); }

    @Override
    public ValidationGraph getUnionGraph()
    { return wrap(super.getUnionGraph()); }

    @Override
    public ValidationGraph getGraph(Node graphNode)
    { return wrap(super.getGraph(graphNode)); }

    private ValidationGraph wrap(Graph g) {
        return new ValidationGraph(g, shapes);
    }

}

